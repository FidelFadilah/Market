from flask import Flask, render_template
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from datetime import datetime, timedelta
import matplotlib.pyplot as plt

app = Flask(__name__)

@app.route('/')
def home():
    # Load the data
    data = pd.read_csv('tomato.csv', parse_dates=['Date'])

    # Ensure the 'Date' column is datetime
    data['Date'] = pd.to_datetime(data['Date'])

    # Extract year, month, and day as features
    data['Year'] = data['Date'].dt.year
    data['Month'] = data['Date'].dt.month
    data['Day'] = data['Date'].dt.day

    # Prepare the features and target
    features = data[['Year', 'Month', 'Day']]
    target = data['Average']

    # Train the model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(features, target)

    # Predict for the next 30 days
    future_dates = [data['Date'].max() + timedelta(days=i) for i in range(1, 31)]
    future_features = pd.DataFrame({
        'Year': [date.year for date in future_dates],
        'Month': [date.month for date in future_dates],
        'Day': [date.day for date in future_dates]
    })
    future_predictions = model.predict(future_features)

    # Calculate monthly averages
    monthly_avg = data.groupby(['Year', 'Month'])['Average'].mean().reset_index()
    monthly_avg['Date'] = pd.to_datetime(monthly_avg[['Year', 'Month']].assign(Day=1))

    # Plotting the future predictions
    plt.figure(figsize=(10, 5))
    plt.plot(future_dates, future_predictions, marker='o')
    plt.title('Prediksi Harga Tomat untuk 30 Hari Kedepan')
    plt.xlabel('Tanggal')
    plt.ylabel('Harga Rata-rata (Average)')
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig('static/future_predictions.png')

    # Plotting the historical monthly averages
    plt.figure(figsize=(10, 5))
    plt.plot(monthly_avg['Date'], monthly_avg['Average'], marker='o')
    plt.title('Rata-rata Bulanan Harga Tomat')
    plt.xlabel('Bulan')
    plt.ylabel('Harga Rata-rata (Average)')
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig('static/monthly_average.png')

    return render_template('index.html', future_predictions=list(zip(future_dates, future_predictions)), monthly_avg=monthly_avg)

if __name__ == '__main__':
    app.run(debug=True)
