from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
import os
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose

app = Flask(__name__)

# Variabel global
data = None
price_column = 'Indonesia(IDR)'  # Nama kolom harga

# Fungsi untuk memuat dan menyiapkan data
def load_data():
    global data
    if os.path.exists('predicted_data.csv'):
        data = pd.read_csv('predicted_data.csv')
    else:
        original_data = pd.read_csv('emas_modified.csv')
        original_data['Month_Year'] = pd.to_datetime(original_data['Month_Year'], format='%b-%y', errors='coerce')
        original_data['Month'] = original_data['Month_Year'].dt.month
        original_data['Year'] = original_data['Month_Year'].dt.year
        data = original_data.copy()

# Fungsi untuk mendeteksi outliers
def detect_outliers(df, column):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = df[(df[column] < lower_bound) | (df[column] > upper_bound)]
    return outliers

# Fungsi untuk menerapkan regresi linier
def apply_linear_regression():
    global data
    if data.empty or 'Year' not in data.columns:
        return

    train_data = data[data['Year'] >= 2010].copy()
    if train_data.empty:
        return

    train_data['Time'] = np.arange(len(train_data))
    X_train = train_data[['Time']]
    y_train = train_data[price_column]

    scaler_X = MinMaxScaler()
    X_train_scaled = scaler_X.fit_transform(X_train)

    model = LinearRegression()
    model.fit(X_train_scaled, y_train)

    future_times = np.arange(len(train_data), len(train_data) + 12).reshape(-1, 1)
    future_times_scaled = scaler_X.transform(future_times)
    future_prices = model.predict(future_times_scaled)

    future_dates = pd.date_range(start=train_data['Month_Year'].max(), periods=13, freq='M')[1:]
    future_data = pd.DataFrame({
        'Month_Year': future_dates,
        'Indonesia(IDR)': future_prices,
        'Month': future_dates.month,
        'Year': future_dates.year
    })

    updated_data = pd.concat([data, future_data], ignore_index=True)
    updated_data.to_csv('predicted_data.csv', index=False)
    data = updated_data

    outliers = detect_outliers(data, price_column)
    if not outliers.empty:
        print("Outliers terdeteksi pada data yang diprediksi:")
        print(outliers[['Month_Year', price_column]])

    evaluate_model()

# Fungsi untuk mengevaluasi model
def evaluate_model():
    global data
    if data.empty or 'Year' not in data.columns:
        return

    train_data = data[data['Year'] >= 2010].copy()
    if train_data.empty:
        return

    train_data['Time'] = np.arange(len(train_data))
    X_train = train_data[['Time']]
    y_train = train_data[price_column]

    scaler_X = MinMaxScaler()
    X_train_scaled = scaler_X.fit_transform(X_train)

    model = LinearRegression()
    model.fit(X_train_scaled, y_train)
    train_data['Predicted'] = model.predict(X_train_scaled)

    mae = mean_absolute_error(train_data[price_column], train_data['Predicted'])
    mse = mean_squared_error(train_data[price_column], train_data['Predicted'])
    r2 = r2_score(train_data[price_column], train_data['Predicted'])

    print(f"Metrik Evaluasi Model:")
    print(f"Mean Absolute Error (MAE): {mae:.2f}")
    print(f"Mean Squared Error (MSE): {mse:.2f}")
    print(f"R-squared (R²): {r2:.2f}")

    outliers = detect_outliers(train_data, 'Predicted')
    if not outliers.empty:
        print("Outliers terdeteksi pada data pelatihan:")
        print(outliers[['Month_Year', 'Predicted']])

# Fungsi untuk dekomposisi komponen time series
def decompose_time_series():
    global data
    if data is None or data.empty:
        load_data()

    if not pd.api.types.is_datetime64_any_dtype(data['Month_Year']):
        data['Month_Year'] = pd.to_datetime(data['Month_Year'], errors='coerce')

    # Set 'Month_Year' sebagai index
    data.set_index('Month_Year', inplace=True)

    # Dekomposisi time series
    result = seasonal_decompose(data[price_column], model='multiplicative', period=12)  # Periode 12 untuk data bulanan

    # Plot hasil dekomposisi dalam satu diagram
    plt.figure(figsize=(12, 8))

    plt.plot(result.trend, color='blue', label='Trend')
    plt.plot(result.seasonal, color='green', label='Seasonal')
    plt.plot(result.resid, color='red', label='Residual')
    plt.plot(result.observed, color='orange', label='Original Data')

    plt.title('Time Series Decomposition')
    plt.xlabel('Month-Year')
    plt.ylabel('Price (IDR)')
    plt.legend()
    plt.grid(True)

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')

    # Kembalikan index ke bentuk semula
    data.reset_index(inplace=True)

    return plot_url

# Route untuk halaman utama
@app.route('/')
def index():
    global data
    if data is None:
        load_data()

    if not pd.api.types.is_datetime64_any_dtype(data['Month_Year']):
        data['Month_Year'] = pd.to_datetime(data['Month_Year'], errors='coerce')

    data = data.dropna(subset=['Month_Year', price_column])

    plt.figure(figsize=(10, 6))
    plt.plot(data['Month_Year'], data[price_column], marker='o')
    plt.xticks(rotation=45)
    plt.title('Harga Emas Historis (25g)')
    plt.xlabel('Bulan-Tahun')
    plt.ylabel('Harga (IDR)')
    plt.grid(True)

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')

    table_html = data[['Month_Year', price_column]].to_html(index=False, classes='table table-striped')

    return render_template('index.html', plot_url=plot_url, table_html=table_html)

# Route untuk dashboard
@app.route('/dashboard')
def dashboard():
    global data
    if data is None:
        load_data()

    avg_price = data[price_column].mean()
    max_price = data[price_column].max()
    min_price = data[price_column].min()
    total_records = len(data)

    return render_template('dashboard.html', avg_price=avg_price, max_price=max_price, min_price=min_price,
                           total_records=total_records)

# Route untuk halaman prediksi
@app.route('/predict', methods=['GET', 'POST'])
def predict():
    global data
    if data is None:
        load_data()

    if request.method == 'POST':
        apply_linear_regression()

    if not pd.api.types.is_datetime64_any_dtype(data['Month_Year']):
        data['Month_Year'] = pd.to_datetime(data['Month_Year'], errors='coerce')

    data = data.dropna(subset=['Month_Year', price_column])

    plt.figure(figsize=(10, 6))
    plt.plot(data['Month_Year'], data[price_column], marker='o', label='Data Historis')
    plt.xticks(rotation=45)
    plt.title('Harga Emas Historis dan Prediksi (25g)')
    plt.xlabel('Bulan-Tahun')
    plt.ylabel('Harga (IDR)')
    plt.grid(True)
    plt.legend()

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')

    table_html = data[['Month_Year', price_column]].to_html(index=False, classes='table table-striped')

    return render_template('predict.html', plot_url=plot_url, table_html=table_html)

# Route untuk mereset data
@app.route('/reset')
def reset_data():
    global data
    if os.path.exists('predicted_data.csv'):
        os.remove('predicted_data.csv')
    load_data()
    return redirect(url_for('dashboard'))

# Route untuk menghitung utang
@app.route('/calculate_debt', methods=['POST'])
def calculate_debt():
    global data
    if data is None:
        load_data()

    try:
        loan_amount = float(request.form['loan_amount'])
        borrow_date = request.form['borrow_date']
        repay_date = request.form['repay_date']

        borrow_date = pd.to_datetime(borrow_date)
        repay_date = pd.to_datetime(repay_date)

        gold_price_borrow = data.loc[data['Month_Year'] == borrow_date, price_column].values[0]
        gold_price_repay = data.loc[data['Month_Year'] == repay_date, price_column].values[0]

        debt_amount = (loan_amount / gold_price_borrow) * gold_price_repay

        return render_template('debt_result.html', loan_amount=loan_amount, debt_amount=debt_amount,
                               gold_price_borrow=gold_price_borrow, gold_price_repay=gold_price_repay)
    except Exception as e:
        return f"Error: {str(e)}"

# Route untuk dekomposisi time series
@app.route('/decomposition')
def decomposition():
    plot_url = decompose_time_series()
    return render_template('decomposition.html', plot_url=plot_url)

if __name__ == '__main__':
    load_data()
    app.run(debug=True)
