import numpy as np
import librosa
import os
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, LSTM, TimeDistributed, Dropout, Input
from tensorflow.keras.layers import Reshape
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping
import joblib

# Fungsi untuk mengaugmentasi audio
def augment_audio(audio, sr):
    augmented_audios = []
    noise = np.random.randn(len(audio))
    audio_noise = audio + 0.005 * noise
    augmented_audios.append(audio_noise)
    audio_speed_up = librosa.effects.time_stretch(audio, rate=1.2)
    audio_slow_down = librosa.effects.time_stretch(audio, rate=0.8)
    augmented_audios.append(audio_speed_up)
    augmented_audios.append(audio_slow_down)
    audio_pitch_up = librosa.effects.pitch_shift(audio, sr=sr, n_steps=2)
    audio_pitch_down = librosa.effects.pitch_shift(audio, sr=sr, n_steps=-2)
    augmented_audios.append(audio_pitch_up)
    augmented_audios.append(audio_pitch_down)
    return augmented_audios

# Fungsi untuk memuat dan mengekstraksi ciri dari file audio menggunakan mel-spectrogram
def load_audio_files(directory, sr=16000, n_mels=128, max_pad_len=100):
    features = []
    labels = []
    label_mapping = {
        "beriresep": 0, "saranmasak": 1, "balado": 2, "capcai": 3,
        "dadar": 4, "dadarsayuran": 5, "kari": 6, "nasigoreng": 7, "hai": 8
    }
    for file in os.listdir(directory):
        if file.endswith(".wav"):
            label_str = file.split("_")[0]
            if label_str in label_mapping:
                label = label_mapping[label_str]
                audio, sr = librosa.load(os.path.join(directory, file), sr=sr)
                mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr, n_mels=n_mels)
                mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
                pad_width = max_pad_len - mel_spec_db.shape[1]
                if pad_width > 0:
                    mel_spec_db = np.pad(mel_spec_db, pad_width=((0, 0), (0, pad_width)), mode='constant')
                else:
                    mel_spec_db = mel_spec_db[:, :max_pad_len]
                features.append(mel_spec_db)
                labels.append(label)
                augmented_audios = augment_audio(audio, sr)
                for aug_audio in augmented_audios:
                    mel_spec_aug = librosa.feature.melspectrogram(y=aug_audio, sr=sr, n_mels=n_mels)
                    mel_spec_db_aug = librosa.power_to_db(mel_spec_aug, ref=np.max)
                    pad_width = max_pad_len - mel_spec_db_aug.shape[1]
                    if pad_width > 0:
                        mel_spec_db_aug = np.pad(mel_spec_db_aug, pad_width=((0, 0), (0, pad_width)), mode='constant')
                    else:
                        mel_spec_db_aug = mel_spec_db_aug[:, :max_pad_len]
                    features.append(mel_spec_db_aug)
                    labels.append(label)
    return np.array(features), np.array(labels)

# Memuat data pelatihan
X, y = load_audio_files("D:/tubesPU/DN")

# Normalisasi fitur
X = np.expand_dims(X, -1)
scaler = StandardScaler()
n_samples, n_mels, n_frames, _ = X.shape
X = scaler.fit_transform(X.reshape(-1, n_mels * n_frames)).reshape(n_samples, n_mels, n_frames, -1)

# Menyimpan scaler untuk digunakan nanti
joblib.dump(scaler, "scaler.pkl")

# Membagi data menjadi data pelatihan dan pengujian
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Mengubah label menjadi bentuk one-hot encoding
num_classes = len(np.unique(y))  # Menghitung jumlah kelas
y_train_cat = to_categorical(y_train, num_classes=num_classes)
y_test_cat = to_categorical(y_test, num_classes=num_classes)

# Membangun model CNN-LSTM dengan objek Input
model = Sequential([
    Input(shape=(n_mels, n_frames, 1)),
    Conv2D(32, kernel_size=(3, 3), activation='relu'),
    MaxPooling2D(pool_size=(2, 2)),
    Dropout(0.25),
    TimeDistributed(Flatten()),
    LSTM(64, return_sequences=True),
    Dropout(0.25),
    LSTM(64),
    Dense(128, activation='relu'),
    Dense(num_classes, activation='softmax')  # Mengatur jumlah output sesuai dengan jumlah kelas
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Pelatihan model dengan early stopping
early_stopping = EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)
model.fit(X_train, y_train_cat, epochs=50, batch_size=32, validation_split=0.2, callbacks=[early_stopping])

# Evaluasi model
loss, accuracy = model.evaluate(X_test, y_test_cat)
print("Akurasi pada data pengujian:", accuracy)

# Menyimpan model dalam format Keras baru
model.save("speech_recognition_cnn_lstm_model_mel_spec.keras")
