import tkinter as tk
from tkinter import ttk
import sounddevice as sd
import numpy as np
import librosa
import matplotlib.pyplot as plt
import pyttsx3
from tensorflow.keras.models import load_model
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler
import joblib
import threading
import tensorflow as tf
import os
import random

# Initialize TTS engine
engine = pyttsx3.init()

# Set TTS voice to female
voices = engine.getProperty('voices')
for voice in voices:
    if 'male' in voice.name.lower():
        engine.setProperty('voice', voice.id)
        break

# Function to record audio
def record_audio(duration, fs):
    print("Silakan bicara...")
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()  # Wait until the recording is finished
    return recording.flatten()

# Function to extract features from audio signal using mel-spectrogram
def extract_features(audio, sr, n_mels=128, max_pad_len=100):
    mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr, n_mels=n_mels)
    mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
    pad_width = max_pad_len - mel_spec_db.shape[1]
    if pad_width > 0:
        mel_spec_db = np.pad(mel_spec_db, pad_width=((0, 0), (0, pad_width)), mode='constant')
    else:
        mel_spec_db = mel_spec_db[:, :max_pad_len]
    return mel_spec_db

# Function to respond based on prediction using text file
def respond_to_prediction(prediction):
    try:
        if prediction == 'saranmasak':
            available_labels = ["balado", "capcai", "dadar", "dadarsayuran", "kari", "nasigoreng"]
            chosen_label = random.choice(available_labels)
            response_file = f'responses/{chosen_label}.txt'
        else:
            response_file = f'responses/{prediction}.txt'
        with open(response_file, 'r') as file:
            return file.read()
    except FileNotFoundError:
        return "File respons tidak ditemukan."

# Function to convert text to speech
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function to display waveform and spectrogram
def plot_waveform_and_spectrogram(audio, sr):
    plt.figure(figsize=(14, 5))
    plt.subplot(1, 2, 1)
    plt.plot(audio)
    plt.title("Waveform")
    plt.subplot(1, 2, 2)
    mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr)
    mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
    librosa.display.specshow(mel_spec_db, sr=sr, x_axis='time', y_axis='mel')
    plt.colorbar(format='%+2.0f dB')
    plt.title('Mel-Spectrogram')
    plt.tight_layout()
    plt.show()

# Define the tf.function outside the loop
@tf.function(reduce_retracing=True)
def make_prediction(model, features):
    return model(features)

# Function to start prediction process
def start_prediction():
    duration = 5  # Recording duration in seconds
    fs = 16000  # Sampling rate (samples per second)

    # Record audio
    audio = record_audio(duration, fs)

    # Display waveform and spectrogram
    plot_waveform_and_spectrogram(audio, fs)

    # Extract features
    features = extract_features(audio, fs)
    features = np.expand_dims(features, axis=-1)
    features = np.expand_dims(features, axis=0)  # Add batch size dimension

    # Load model without optimizer and recompile it
    model = load_model("speech_recognition_cnn_lstm_model_mel_spec.keras", compile=False)
    model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

    # Load the scaler used when training the model
    scaler = joblib.load("scaler.pkl")
    n_samples, n_mels, n_frames, _ = features.shape
    features = scaler.transform(features.reshape(-1, n_mels * n_frames)).reshape(n_samples, n_mels, n_frames, -1)

    # Make prediction using the precompiled function
    prediction = make_prediction(model, features)
    predicted_label = np.argmax(prediction, axis=1)[0]

    # Map numeric label to string label
    label_mapping = {
        0: "beriresep", 1: "saranmasak", 2: "balado", 3: "capcai",
        4: "dadar", 5: "dadarsayuran", 6: "kari", 7: "nasigoreng", 8: "hai"
    }
    predicted_label_str = label_mapping.get(predicted_label, "unknown")

    # Display result
    result_text = "Anda mengatakan: " + predicted_label_str
    response_text = "Respon: " + respond_to_prediction(predicted_label_str)

    result_label.config(text=result_text)
    response_label.config(text=response_text)

    # Convert response to speech
    speak(response_text)

# Function to reset the display
def reset():
    result_label.config(text="")
    response_label.config(text="")

# Function to run prediction in a separate thread
def threaded_prediction():
    threading.Thread(target=start_prediction).start()

# Function to change theme
def change_theme(theme):
    themes = {
        "Hangat": {
            "bg": "#FFF4E6",
            "fg": "#754C24",
            "frame_bg": "#FFF1D6",
            "record_bg": "#BF8040",
            "reset_bg": "#C24641",
        },
        "Cerah": {
            "bg": "#E9F1F7",
            "fg": "#1976D2",
            "frame_bg": "#D9E4F5",
            "record_bg": "#4CAF50",
            "reset_bg": "#FF5722",
        },
        "Natural": {
            "bg": "#F5F5DC",
            "fg": "#5D4037",
            "frame_bg": "#F2E5BC",
            "record_bg": "#8BC34A",
            "reset_bg": "#D32F2F",
        },
    }

    colors = themes.get(theme, themes["Hangat"])

    root.configure(bg=colors["bg"])
    title_label.configure(foreground=colors["fg"], background=colors["bg"])

    # Configure style for LabelFrame
    style.configure("TLabelframe", background=colors["frame_bg"])
    style.configure("TLabelframe.Label", background=colors["frame_bg"], foreground=colors["fg"])

    style.configure("Record.TButton", background=colors["record_bg"])
    style.configure("Reset.TButton", background=colors["reset_bg"])

    # Set background of labels to be transparent (same as parent widget)
    result_label.configure(background=colors["frame_bg"], foreground=colors["fg"])
    response_label.configure(background=colors["frame_bg"], foreground=colors["fg"])

# Create GUI using tkinter
root = tk.Tk()
root.title("Voice Command Recognition")
root.geometry("500x450")  # Adjust window size

# Styling
style = ttk.Style()
style.theme_use('clam')  # Apply a visually appealing theme

title_label = ttk.Label(root, text="Voice Command Recognition", font=("Helvetica", 20, "bold"))
title_label.pack(pady=20)

# Frame for buttons and theme selection
button_frame = ttk.Frame(root)
button_frame.pack(pady=10)

record_button = ttk.Button(button_frame, text="Mulai Rekam", command=threaded_prediction, style='Record.TButton')
record_button.pack(side=tk.LEFT, padx=5)

reset_button = ttk.Button(button_frame, text="Reset", command=reset, style='Reset.TButton')
reset_button.pack(side=tk.LEFT, padx=5)

theme_label = ttk.Label(button_frame, text="Tema:")
theme_label.pack(side=tk.LEFT, padx=10)

theme_var = tk.StringVar(value="Hangat")  # Default theme
theme_options = ["Hangat", "Cerah", "Natural"]
theme_dropdown = ttk.Combobox(button_frame, textvariable=theme_var, values=theme_options)
theme_dropdown.pack(side=tk.LEFT)
theme_dropdown.bind("<<ComboboxSelected>>", lambda event: change_theme(theme_var.get()))

# Frame for results and response (with borders)
result_frame = ttk.LabelFrame(root, text="Hasil")
result_frame.pack(pady=20, padx=20, fill=tk.BOTH, expand=True)

result_label = ttk.Label(result_frame, text="", font=("Helvetica", 14))
result_label.pack(pady=10, padx=10, fill=tk.X)

response_label = ttk.Label(result_frame, text="", font=("Helvetica", 14))
response_label.pack(pady=10, padx=10, fill=tk.X)

# Initial theme setup
change_theme("Hangat")  # Set initial theme when program starts

root.mainloop()
