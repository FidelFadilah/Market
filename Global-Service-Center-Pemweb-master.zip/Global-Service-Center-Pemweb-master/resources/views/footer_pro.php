<footer>
        <p>Hak Cipta &copy; <?php echo date("Y"); ?> Global Service Center</p>
    </footer>
</body>

</html>
